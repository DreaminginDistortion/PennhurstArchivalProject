/ Pennhurst Historical Archive - Shared JavaScript
// Accessibility and interaction features

// Font size adjustment
let currentFontSize = 100;

function increaseFontSize() {
    currentFontSize = Math.min(currentFontSize + 10, 150);
    document.documentElement.style.fontSize = currentFontSize + '%';
    localStorage.setItem('fontSize', currentFontSize);
    announceToScreenReader('Text size increased to ' + currentFontSize + ' percent');
}

function decreaseFontSize() {
    currentFontSize = Math.max(currentFontSize - 10, 75);
    document.documentElement.style.fontSize = currentFontSize + '%';
    localStorage.setItem('fontSize', currentFontSize);
    announceToScreenReader('Text size decreased to ' + currentFontSize + ' percent');
}

function resetFontSize() {
    currentFontSize = 100;
    document.documentElement.style.fontSize = '100%';
    localStorage.setItem('fontSize', currentFontSize);
    announceToScreenReader('Text size reset to default');
}

// High contrast mode toggle
function toggleHighContrast() {
    document.body.classList.toggle('high-contrast');
    const isHighContrast = document.body.classList.contains('high-contrast');
    localStorage.setItem('highContrast', isHighContrast);
    announceToScreenReader(isHighContrast ? 'High contrast mode enabled' : 'High contrast mode disabled');
}

// Screen reader announcements
function announceToScreenReader(message) {
    const announcement = document.createElement('div');
    announcement.setAttribute('role', 'status');
    announcement.setAttribute('aria-live', 'polite');
    announcement.setAttribute('aria-atomic', 'true');
    announcement.classList.add('sr-only');
    announcement.textContent = message;
    document.body.appendChild(announcement);
    
    setTimeout(() => {
        document.body.removeChild(announcement);
    }, 1000);
}

// Smooth scrolling for navigation links
document.addEventListener('DOMContentLoaded', function() {
    // Restore saved preferences
    const savedFontSize = localStorage.getItem('fontSize');
    if (savedFontSize) {
        currentFontSize = parseInt(savedFontSize);
        document.documentElement.style.fontSize = currentFontSize + '%';
    }
    
    const savedHighContrast = localStorage.getItem('highContrast');
    if (savedHighContrast === 'true') {
        document.body.classList.add('high-contrast');
    }
    
    // Smooth scrolling for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            const targetId = this.getAttribute('href');
            if (targetId === '#') return;
            
            const target = document.querySelector(targetId);
            if (target) {
                e.preventDefault();
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
                // Focus the target for screen readers
                target.setAttribute('tabindex', '-1');
                target.focus();
            }
        });
    });
    
    // Keyboard navigation enhancement
    document.addEventListener('keydown', function(e) {
        // Escape key returns focus to main content
        if (e.key === 'Escape') {
            const mainContent = document.getElementById('main-content');
            if (mainContent) {
                mainContent.focus();
            }
        }
    });
    
    // Enhanced focus visibility for keyboard navigation
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Tab') {
            document.body.classList.add('keyboard-nav');
        }
    });
    
    document.addEventListener('mousedown', function() {
        document.body.classList.remove('keyboard-nav');
    });
});

// Add CSS for screen reader only content
const style = document.createElement('style');
style.textContent = `
    .sr-only {
        position: absolute;
        width: 1px;
        height: 1px;
        padding: 0;
        margin: -1px;
        overflow: hidden;
        clip: rect(0, 0, 0, 0);
        white-space: nowrap;
        border-width: 0;
    }
    
    body.keyboard-nav *:focus {
        outline: 3px solid #654321;
        outline-offset: 2px;
    }
`;
document.head.appendChild(style);